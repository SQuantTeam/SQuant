
window.baseUrl = "http://localhost:8000/squant/";
