export const currentUser = state => state.currentUser
export const isLogin = state => state.isLogin