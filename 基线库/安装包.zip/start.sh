#/bin/bash
sudo /usr/bin/python manage.py runserver 0.0.0.0:8000 --nothreading --noreload
