# -*- coding: UTF-8 -*-
# encoding: utf-8

"""
Define which filed to use in dataview by stock selection index and rank index.

"""

